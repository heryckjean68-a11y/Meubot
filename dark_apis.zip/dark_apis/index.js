const express = require('express');
const session = require('express-session');
const fs = require('fs');
const cheerio = require('cheerio');
const path = require('path');
const axios = require('axios');
const cors = require('cors');
const ytSearch = require('yt-search');
const readline = require('readline');
const https = require('https');
const gplay = require('google-play-scraper');

const app = express();
const PORT = 3000;

const MENU_CONFIG = {
    "consultas": [
        { id: "NOME", icon: "fa-user", titulo: "CONSULTA NOME", desc: "Base Local", prompt: "Digite o Nome" },
        { id: "CPF", icon: "fa-id-card", titulo: "CONSULTA CPF", desc: "Base Local", prompt: "Digite o CPF" },
        { id: "CEP", icon: "fa-map-marker-alt", titulo: "CONSULTA CEP", desc: "ViaCEP", prompt: "Digite o CEP" },
        { id: "CNPJ", icon: "fa-building", titulo: "CONSULTA CNPJ", desc: "BrasilAPI", prompt: "Digite o CNPJ" },
        { id: "IP", icon: "fa-network-wired", titulo: "GEO IP", desc: "Localizar IP", prompt: "IP (vazio = seu)" }
    ],
    "downloads": [
        { id: "YT_SEARCH", icon: "fa-search", titulo: "YT PESQUISA", desc: "Pesquisar no yt", prompt: "Nome do vídeo" },
{ id: "MEDIAFIRE", icon: "fa-fire", titulo: "MEDIAFIRE", desc: "Link Direto", prompt: "Cole o Link" },
        { id: "TIKTOK", icon: "fa-music", titulo: "TIKTOK", desc: "Sem marca d'água", prompt: "Link do TikTok" },
        { id: "INSTAGRAM", icon: "fa-camera-retro", titulo: "INSTAGRAM", desc: "Reels/Post/Story", prompt: "Link do Insta" }, 
        { id: "PLAYSTORE", icon: "fa-google-play", titulo: "PLAY STORE", desc: "Buscar Apps", prompt: "Nome do App" },
        { id: "WALLPAPER", icon: "fa-image", titulo: "WALLPAPER", desc: "Wallpaper aleatório", prompt: null },
        { id: "PINTEREST", icon: "fa-pinterest", titulo: "PINTEREST", desc: "Buscar Imagens", prompt: "Ex: Tatuagem" },
        { id: "YT_AUDIO", icon: "fa-music", titulo: "YT AUDIO", desc: "Baixar áudio", prompt: "link do vídeo ou nome" },
        { id: "YT_VIDEO", icon: "fa-video", titulo: "YouTube Video", desc: "Baixa a música direto (MP4)", prompt: "Nome ou Link" },
        { id: "REDDIT", icon: "fa-reddit", titulo: "MEME REDDIT", desc: "Memes Do Reddit", prompt: null }
    ],
    "ias": [
        { id: "GPT", icon: "fa-robot", titulo: "CHAT GPT-4", desc: "IA Inteligente", prompt: "Sua pergunta" },
        { id: "GEMINI", icon: "fa-brain", titulo: "GEMINI", desc: "Google AI", prompt: "Sua pergunta" }
    ],
    "ferramentas": [
        { id: "CLIMA", icon: "fa-cloud", titulo: "CLIMA / TEMPO", desc: "Previsão", prompt: "Nome da Cidade" },
        { id: "GERAR_NICK", icon: "fa-font", titulo: "GERADOR NICK", desc: "Estilos de fonte", prompt: "Seu nome" }, 
        { id: "TRADUTOR", icon: "fa-language", titulo: "TRADUTOR", desc: "PT-BR / EN", prompt: "Texto para traduzir" },
        { id: "ENCURTAR", icon: "fa-compress", titulo: "ENCURTADOR", desc: "TinyURL", prompt: "Cole o Link" },
        { id: "PRINTSITE", icon: "fa-camera", titulo: "PRINTSITE", desc: "Print de Site", prompt: "URL do site (ex: google.com)" },
        { id: "TTS", icon: "fa-volume-up", titulo: "TEXTO PARA VOZ", desc: "Áudio do Google", prompt: "O que eu devo falar?" }
    ],
    "fig": [
    { id: "FIGU_ANIMAL", icon: "fa-paw", titulo: "ANIMAIS", desc: "Fofos e Engraçados", prompt: null },
    { id: "FIGU_FUNNY", icon: "fa-grin-tears", titulo: "FIGURINHA ENGRAÇADA", desc: "Meme Aleatório", prompt: null },
    { id: "FIGU_DESENHO", icon: "fa-pencil-alt", titulo: "DESENHO", desc: "Aleatório", prompt: null },
{ id: "FIGU_RAIVA", icon: "fa-angry", titulo: "FIGURINHA BRAVA", desc: "Meme pistola", prompt: null },
        { id: "FIGU_EMOJI", icon: "fa-icons", titulo: "FIGURINHA EMOJI", desc: "Meme/Emoji Aleatório", prompt: null },
        { id: "FIGURINHAS", icon: "fa-sticky-note", titulo: "FIGURINHAS", desc: "Pack Aleatório", prompt: null },
        { id: "ROBLOX", icon: "fa-gamepad", titulo: "STICKER ROBLOX", desc: "Aleatório", prompt: null },
        { id: "FIGU_ANIME", icon: "fa-ghost", titulo: "FIGURINHA ANIME", desc: "Aleatória", prompt: null },
{ id: "ATTP", icon: "fa-bolt", titulo: "ATTP", desc: "Texto Pisca-Pisca", prompt: "Digite o texto" },
{ id: "TTP", icon: "fa-font", titulo: "TTP", desc: "Texto Colorido", prompt: "Digite o texto" },
        { id: "BRAT", icon: "fa-square", titulo: "BRAT IMAGEM", desc: "Meme Verde", prompt: "Texto" },
        { id: "BRAT_VIDEO", icon: "fa-video", titulo: "BRAT VÍDEO", desc: "Animado", prompt: "Texto" }
    ],
    "nsfw": [
    { id: "XNXX", icon: "fa-video", titulo: "XNXX Downloader", desc: "Baixa Vídeo MP4 (+18)", prompt: "Nome da atriz ou termo..." },
    { id: "PH_SEARCH", icon: "fa-video", titulo: " PORN HUB SEARCH", desc: "Pesquisa +18", prompt: "O que procura?" },
        { id: "PLAQUINHA", icon: "fa-venus", titulo: "PLAQUINHA 1", desc: "Texto na Placa", prompt: "Escreva o texto" }
    ],
    "info": [
    { id: "FUTEBOL", icon: "fa-futbol", titulo: "FUTEBOL", desc: "Últimas do Esporte", prompt: null },
        { id: "G1", icon: "fa-newspaper", titulo: "G1 NOTÍCIAS", desc: "Últimas do G1", prompt: null },
{ id: "POLITICA", icon: "fa-landmark", titulo: "POLÍTICA HOJE", desc: "Feed de Notícias", prompt: null }
    ]
};

const DB_DIR = './db';
const PUBLIC_DIR = './public';
const DB_USERS = path.join(DB_DIR, 'users.json');
const DB_NOME = path.join(DB_DIR, 'banconome.json');
const DB_CPF = path.join(DB_DIR, 'bancocpf.json');

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR);
if (!fs.existsSync(PUBLIC_DIR)) fs.mkdirSync(PUBLIC_DIR);

app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.use(session({ secret: 'jean_secret_key', resave: false, saveUninitialized: true }));

function getDB() {
    if (!fs.existsSync(DB_USERS)) {
        const padrao = { "admin": { "credits": 999999} };
        fs.writeFileSync(DB_USERS, JSON.stringify(padrao, null, 4));
    }
    try { return JSON.parse(fs.readFileSync(DB_USERS)); } catch { return {}; }
}
function saveDB(data) { fs.writeFileSync(DB_USERS, JSON.stringify(data, null, 4)); }

function stylizeText(text) {
    // Caracteres originais para referência (A-Z, a-z, 0-9)
    const normal = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    // Dicionário com as fontes (A ordem dos caracteres TEM que bater com a string 'normal' acima)
    const fonts = {
        bold: "𝐀𝐁𝐂𝐃𝐄𝐅𝐆𝐇𝐈𝐉𝐊𝐋𝐌𝐍𝐎𝐏𝐐𝐑𝐒𝐓𝐔𝐕𝐖𝐗𝐘𝐙𝐚𝐛𝐜𝐝𝐞𝐟𝐠𝐡𝐢𝐣𝐤𝐥𝐦𝐧𝐨𝐩𝐪𝐫𝐬𝐭𝐮𝐯𝐰𝐱𝐲𝐳𝟎𝟏𝟐𝟑𝟒𝟓𝟔𝟕𝟖𝟗",
        italic: "𝐴𝐵𝐶𝐷𝐸𝐹𝐺𝐻𝐼𝐽𝐾𝐿𝑀𝑁𝑂𝑃𝑄𝑅𝑆𝑇𝑈𝑉𝑊𝑋𝑌𝑍𝑎𝑏𝑐𝑑𝑒𝑓𝑔ℎ𝑖𝑗𝑘𝑙𝑚𝑛𝑜𝑝𝑞𝑟𝑠𝑡𝑢𝑣𝑤𝑥𝑦𝑧0123456789",
        script: "𝒜ℬ𝒞𝒟ℰℱ𝒢ℋℐ𝒥𝒦ℒℳ𝒩𝒪𝒫𝒬ℛ𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵𝒶𝒷𝒸𝒹ℯ𝒻ℊ𝒽𝒾𝒿𝓀𝓁𝓂𝓃ℴ𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏0123456789",
        gothic: "𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷0123456789",
        monospace: "𝙰𝙱𝙲𝙳𝙴𝙵𝙶𝙷𝙸𝙹𝙺𝙻𝙼𝙽𝙾𝙿𝚚𝚁𝚂𝚃𝚄𝚅𝚆𝚇𝚈𝚉𝚊𝚋𝚌𝚍𝚎𝚏𝚐𝚑𝚒𝚓𝚔𝚕𝚖𝚗𝚘𝚙𝚚𝚛𝚜𝚝𝚞𝚟𝚠𝚡𝚢𝚣𝟶𝟷𝟸𝟹𝟺𝟻𝟼𝟽𝟾𝟿",
        double: "𝔸𝔹ℂ𝔻𝔼𝔽𝔾ℍ𝕀𝕁𝕂𝕃𝕄ℕ𝕆ℙℚℝ𝕊𝕋𝕌𝕍𝕎𝕏𝕐ℤ𝕒𝕓𝕔𝕕𝕖𝕗𝕘𝕙𝕚𝕛𝕜𝕝𝕞𝕟𝕠𝕡𝕢𝕣𝕤𝕥𝕦𝕧𝕨𝕩𝕪𝕫𝟘𝟙𝟚𝟛𝟜𝟝𝟞𝟟𝟠𝟡",
        circled: "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ0123456789",
        wide: "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ０１２３４５６７８９",
        smallcaps: "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ0123456789", // Maiusculas e minusculas ficam iguais
    };

    // Objeto de retorno
    const result = {
        original: text,
        reverse: text.split('').reverse().join('')
    };

    // Função auxiliar para mapear
    const applyFont = (str, fontKey) => {
        return str.split('').map(char => {
            const index = normal.indexOf(char);
            // Se achou o caractere na lista normal, troca pelo da fonte. Se não (espaço, emoji), mantém igual.
            return index !== -1 ? fonts[fontKey][index * 2] + fonts[fontKey][index * 2 + 1] : char; 
            // OBS: Algumas fontes usam 2 bytes (surrogate pairs). Para segurança, vamos usar array real:
        }).join('');
    };
    
    // Método MAIS SEGURO (corrige bug de caracteres invisíveis/quebrados)
    const safeApply = (str, fontString) => {
        // Converte as strings em arrays reais de símbolos (resolve problema de emojis e surrogate pairs)
        const normalArray = Array.from(normal);
        const fontArray = Array.from(fontString);
        
        return Array.from(str).map(char => {
            const index = normalArray.indexOf(char);
            if (index !== -1 && fontArray[index]) {
                return fontArray[index];
            }
            return char;
        }).join('');
    };

    // Gera todas as fontes do dicionário automaticamente
    Object.keys(fonts).forEach(style => {
        result[style] = safeApply(text, fonts[style]);
    });

    // Lógica especial para INVERTER (Upside Down) - precisa de mapa próprio
    const flipMap = {'a':'ɐ','b':'q','c':'ɔ','d':'p','e':'ǝ','f':'ɟ','g':'ƃ','h':'ɥ','i':'ᴉ','j':'ɾ','k':'ʞ','l':'l','m':'ɯ','n':'u','o':'o','p':'d','q':'b','r':'ɹ','s':'s','t':'ʇ','u':'n','v':'ʌ','w':'ʍ','x':'x','y':'ʎ','z':'z','A':'∀','B':'q','C':'Ɔ','D':'p','E':'Ǝ','F':'Ⅎ','G':'𓍊','H':'H','I':'I','J':'ſ','K':'⋊','L':'⅂','M':'W','N':'N','O':'O','P':'Ԁ','Q':'Ò','R':'ᴚ','S':'S','T':'⊥','U':'∩','V':'Λ','W':'M','X':'X','Y':'⅄','Z':'Z','1':'1','2':'2','3':'Ɛ','4':'h','5':'5','6':'9','7':'7','8':'8','9':'6','0':'0','.':'˙',',':'\'','?':'¿','!':'¡','"':',,'};
    
    result['upside_down'] = text.split('').reverse().map(c => flipMap[c] || c).join('');

    return result;
}

// ======================================================
// 🔍 ROTA SIMPLIFICADA (SEM PLANO)
// ======================================================
app.get('/check-key', (req, res) => {
    const apikey = req.query.apikey;
    const db = getDB();
    const user = db[apikey];

    if (user) {
        res.json({
            valid: true,
            limit: user.limit || 0 // Retorna apenas o limite numérico
        });
    } else {
        res.json({ valid: false });
    }
});

app.get('/', (req, res) => {
    // 1. Gerar Menu e Conteúdo
    let menuItens = "";
    let conteudoTabs = "";

    for (const [categoria, itens] of Object.entries(MENU_CONFIG)) {
        menuItens += `
        <li onclick="abrirTab('${categoria}')">
            <i class="fas fa-folder-open"></i> ${categoria.toUpperCase()}
        </li>`;
        
        let cards = "";
        itens.forEach(item => {
            const pText = item.prompt ? item.prompt.replace(/'/g, "\\'") : ''; 
            
            cards += `
            <div class="card">
                <div class="card-glow"></div>
                <div class="card-header">
                    <span class="badge">GET</span>
                    <span class="endpoint">/${categoria}/${item.id}</span>
                </div>
                <div class="card-body">
                    <h3><i class="fas ${item.icon}"></i> ${item.titulo}</h3>
                    <p>${item.desc}</p>
                </div>
                <button class="btn-run" onclick="executarRota('${categoria}', '${item.id}', '${pText}')">
                    <span class="text">EXECUTAR</span>
                    <span class="icon"><i class="fas fa-arrow-right"></i></span>
                </button>
            </div>`;
        });

        conteudoTabs += `
        <div id="view-${categoria}" class="tab-content">
            <div class="section-header">
                <h1 class="gradient-text">${categoria.toUpperCase()}</h1>
                <span class="counter">${itens.length} ROTAS</span>
            </div>
            <div class="grid-container">${cards}</div>
        </div>`;
    }

    res.send(`
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>NEXUS | Developer Hub</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;500;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --bg-dark: #050505;
                --sidebar-bg: rgba(15, 15, 20, 0.7);
                --card-bg: rgba(255, 255, 255, 0.03);
                --border: rgba(255, 255, 255, 0.08);
                --primary: #00d2ff;
                --secondary: #9d00ff;
                --text-main: #ffffff;
                --text-muted: #8b8b93;
                --gradient: linear-gradient(135deg, var(--primary), var(--secondary));
            }

            * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
            
            body { 
                margin: 0; 
                font-family: 'Outfit', sans-serif; 
                background: var(--bg-dark); 
                color: var(--text-main); 
                display: flex; 
                height: 100vh; 
                overflow: hidden;
                /* Fundo com efeito sutil */
                background-image: 
                    radial-gradient(circle at 15% 50%, rgba(157, 0, 255, 0.08), transparent 25%), 
                    radial-gradient(circle at 85% 30%, rgba(0, 210, 255, 0.08), transparent 25%);
            }

            /* === SIDEBAR (VIDRO) === */
            .sidebar { 
                width: 270px; 
                background: var(--sidebar-bg);
                backdrop-filter: blur(20px);
                border-right: 1px solid var(--border); 
                display: flex; flex-direction: column; 
                z-index: 100;
                transition: transform 0.3s ease;
            }
            
            .logo-area {
                padding: 30px;
                font-size: 1.5rem;
                font-weight: 700;
                letter-spacing: 1px;
                background: var(--gradient);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                border-bottom: 1px solid var(--border);
                display: flex; align-items: center; gap: 10px;
            }

            .menu-scroll { flex: 1; overflow-y: auto; padding: 20px 10px; list-style: none; margin: 0; }
            
            .menu-scroll li {
                padding: 14px 20px; 
                margin-bottom: 5px;
                cursor: pointer; 
                color: var(--text-muted); 
                font-size: 0.95rem;
                font-weight: 500;
                border-radius: 12px;
                transition: all 0.3s ease;
                display: flex; align-items: center; gap: 12px;
            }
            
            .menu-scroll li:hover { background: rgba(255,255,255,0.05); color: #fff; }
            
            .menu-scroll li.active {
                background: linear-gradient(90deg, rgba(0, 210, 255, 0.1), transparent);
                color: var(--primary);
                border-left: 3px solid var(--primary);
            }

            .sidebar-footer { padding: 20px; border-top: 1px solid var(--border); }
            
            .btn-admin {
                display: flex; justify-content: center; align-items: center; gap: 10px;
                width: 100%; padding: 12px;
                background: rgba(255, 50, 50, 0.1);
                color: #ff4d4d;
                text-decoration: none; border-radius: 10px;
                font-weight: 600; font-size: 0.8rem;
                border: 1px solid rgba(255, 50, 50, 0.2);
                transition: 0.3s;
            }
            .btn-admin:hover { background: #ff4d4d; color: white; box-shadow: 0 0 15px rgba(255, 77, 77, 0.4); }

            /* === CONTEÚDO PRINCIPAL === */
            .main-content { flex: 1; display: flex; flex-direction: column; width: 100%; position: relative; }

            /* Top Bar Mobile */
            .top-bar {
                display: none; justify-content: space-between; align-items: center;
                padding: 15px 20px; background: rgba(5,5,5,0.9); border-bottom: 1px solid var(--border);
            }
            .btn-menu { background: none; border: none; color: white; font-size: 1.5rem; }

            /* Header Key/Stats */
            .dashboard-header {
                padding: 25px 40px;
                border-bottom: 1px solid var(--border);
                display: flex; flex-wrap: wrap; gap: 20px; align-items: center; justify-content: space-between;
                background: rgba(0,0,0,0.2);
            }

            .search-box {
                flex: 1; max-width: 500px; position: relative;
                background: var(--card-bg); border: 1px solid var(--border);
                border-radius: 12px; display: flex; align-items: center;
                transition: 0.3s;
            }
            .search-box:focus-within { border-color: var(--primary); box-shadow: 0 0 15px rgba(0, 210, 255, 0.1); }
            
            .search-box input {
                flex: 1; background: transparent; border: none; color: white;
                padding: 12px 15px; outline: none; font-family: 'JetBrains Mono'; font-size: 0.9rem;
            }
            .btn-check {
                background: var(--primary); border: none; padding: 0 20px; height: 42px;
                border-radius: 0 11px 11px 0; cursor: pointer; color: #000; font-weight: bold;
            }

            .stats-pill {
                display: flex; align-items: center; gap: 15px;
                background: var(--card-bg); padding: 8px 20px; border-radius: 50px;
                border: 1px solid var(--border);
            }
            .stat-value { font-family: 'JetBrains Mono'; color: var(--primary); font-weight: bold; }

            /* Scroll Area */
            .scroll-area { flex: 1; overflow-y: auto; padding: 40px; }

            /* Section Headers */
            .section-header { margin-bottom: 30px; display: flex; align-items: baseline; gap: 15px; border-bottom: 1px solid var(--border); padding-bottom: 15px; }
            .gradient-text { margin: 0; font-size: 2rem; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
            .counter { font-size: 0.8rem; background: var(--border); padding: 4px 10px; border-radius: 20px; color: var(--text-muted); }

            /* === CARDS MODERNOS === */
            .grid-container {
                display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 25px;
            }

            .card {
                position: relative;
                background: var(--card-bg);
                border: 1px solid var(--border);
                border-radius: 16px;
                padding: 25px;
                display: flex; flex-direction: column; justify-content: space-between;
                transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
                overflow: hidden;
            }

            /* Efeito de Hover (Levitar + Brilho) */
            .card:hover {
                transform: translateY(-5px);
                border-color: rgba(255, 255, 255, 0.2);
                box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5);
                background: rgba(255, 255, 255, 0.05);
            }
            .card:hover h3 i { transform: scale(1.2); color: #fff; }

            .card-header { display: flex; justify-content: space-between; margin-bottom: 15px; }
            .badge { background: rgba(0, 210, 255, 0.1); color: var(--primary); font-size: 0.7rem; padding: 4px 10px; border-radius: 6px; font-weight: 700; letter-spacing: 0.5px; }
            .endpoint { font-family: 'JetBrains Mono'; font-size: 0.75rem; color: var(--text-muted); opacity: 0.7; }

            .card h3 { 
                margin: 0 0 10px 0; font-size: 1.2rem; font-weight: 600; 
                display: flex; align-items: center; gap: 12px; color: #eee;
            }
            .card h3 i { color: var(--primary); transition: 0.3s; }
            
            .card p { font-size: 0.9rem; color: #aaa; margin: 0 0 25px 0; line-height: 1.6; font-weight: 300; }

            .btn-run {
                background: transparent;
                border: 1px solid var(--border);
                color: var(--text-main);
                padding: 12px;
                border-radius: 10px;
                cursor: pointer;
                font-family: 'Outfit'; font-weight: 600; font-size: 0.85rem;
                display: flex; justify-content: space-between; align-items: center;
                transition: 0.3s;
            }
            .btn-run:hover {
                background: var(--primary); border-color: var(--primary); color: #000;
            }

            /* Welcome Screen */
            .welcome-box {
                text-align: center; padding: 60px 20px;
                background: radial-gradient(circle, rgba(255,255,255,0.03) 0%, transparent 70%);
            }

            /* Mobile */
            .overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 90; display: none; backdrop-filter: blur(5px); }
            
            @media (max-width: 768px) {
                .sidebar { position: fixed; height: 100%; transform: translateX(-100%); }
                .sidebar.open { transform: translateX(0); }
                .top-bar { display: flex; }
                .overlay.active { display: block; }
                .dashboard-header { flex-direction: column; align-items: stretch; padding: 20px; }
                .stats-pill { justify-content: space-between; }
                .scroll-area { padding: 20px; }
            }
            .tab-content { display: none; animation: fadeIn 0.4s ease; }
            @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        </style>
    </head>
    <body>

        <div class="overlay" id="overlay" onclick="toggleMenu()"></div>

        <div class="sidebar" id="sidebar">
            <div class="logo-area"><i class="fas fa-cube"></i> NEXUS API</div>
            <ul class="menu-scroll">
                <li onclick="abrirTab('inicio')" class="active"><i class="fas fa-home"></i> Dashboard</li>
                ${menuItens}
            </ul>
            <div class="sidebar-footer">
                <a href="/admin" class="btn-admin" target="_blank"><i class="fas fa-lock"></i> ADMIN PANEL</a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <button class="btn-menu" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
                <span style="font-weight:bold; letter-spacing:1px;">NEXUS V1</span>
                <div style="width:24px"></div>
            </div>

            <div class="dashboard-header">
                <div class="search-box">
                    <input type="text" id="apikey" placeholder="Cole sua API Key aqui..." onkeypress="handleEnter(event)">
                    <button class="btn-check" onclick="verificarKey()"><i class="fas fa-check"></i></button>
                </div>
                
                <div class="stats-pill" id="stats-box" style="opacity: 0.5;">
                    <span style="font-size:0.8rem; color:#aaa;">SALDO</span>
                    <span class="stat-value" id="lbl-limit">---</span>
                    <i class="fas fa-circle" id="status-dot" style="font-size: 8px; color: #444;"></i>
                </div>
            </div>

            <div class="scroll-area">
                <div id="view-inicio" class="tab-content" style="display:block;">
                    <div class="welcome-box">
                        <i class="fas fa-network-wired" style="font-size: 4rem; margin-bottom: 20px; background: var(--gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i>
                        <h1 style="font-size: 2.5rem; margin-bottom: 10px;">Bem-vindo ao Nexus</h1>
                        <p style="color: var(--text-muted); max-width: 500px; margin: 0 auto;">
                            Explore nossa coleção de APIs. Selecione uma categoria no menu lateral para visualizar endpoints e documentação.
                        </p>
                    </div>
                </div>

                ${conteudoTabs}
            </div>
        </div>

        <script>
            // Lógica UI
            function toggleMenu() {
                document.getElementById('sidebar').classList.toggle('open');
                document.getElementById('overlay').classList.toggle('active');
            }

            function abrirTab(id) {
                document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
                document.querySelectorAll('.menu-scroll li').forEach(l => l.classList.remove('active'));
                
                const tab = document.getElementById('view-' + id);
                if(tab) tab.style.display = 'block';
                
                if(window.innerWidth <= 768) toggleMenu();
            }

            // Lógica Key
            const keyInput = document.getElementById('apikey');
            if(localStorage.getItem('user_key')) {
                keyInput.value = localStorage.getItem('user_key');
                verificarKey(); 
            }

            function handleEnter(e) { if(e.key === 'Enter') verificarKey(); }

            async function verificarKey() {
                const key = keyInput.value.trim();
                if(!key) return alert("Digite uma Key.");
                
                localStorage.setItem('user_key', key);
                const btn = document.querySelector('.btn-check');
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

                try {
                    const req = await fetch('/check-key?apikey=' + key);
                    const res = await req.json();

                    if(res.valid) {
                        document.getElementById('lbl-limit').innerText = res.limit;
                        document.getElementById('status-dot').style.color = "var(--primary)";
                        document.getElementById('stats-box').style.opacity = '1';
                        document.querySelector('.search-box').style.borderColor = "var(--primary)";
                    } else {
                        alert("Key Inválida!");
                        document.getElementById('lbl-limit').innerText = "0";
                        document.getElementById('status-dot').style.color = "red";
                        document.querySelector('.search-box').style.borderColor = "red";
                    }
                } catch (e) { alert("Erro de conexão."); }
                
                btn.innerHTML = '<i class="fas fa-check"></i>';
            }

            function executarRota(cat, met, promptText) {
                const key = keyInput.value;
                if(!key) {
                    if(window.innerWidth <= 768) {
                        document.querySelector('.dashboard-header').scrollIntoView({behavior: "smooth"});
                    }
                    keyInput.focus();
                    return alert("⚠️ Digite sua API Key no topo primeiro!");
                }

                let q = "";
                if(promptText && promptText !== 'null') {
                    q = prompt(promptText);
                    if(q === null) return; 
                }

                const url = \`/api/\${cat}/\${met}?apikey=\${key}\${q ? '&q=' + encodeURIComponent(q) : ''}\`;
                window.open(url, '_blank');
            }
        </script>
    </body>
    </html>
    `);
});

// ======================================================
// 🔒 ADMIN PANEL (Gerenciador de Keys)
// ======================================================

// ⚠️ CONFIGURE SEU LOGIN AQUI
const ADMIN_LOGIN = "admin";
const ADMIN_SENHA = "123"; 

// Middleware de Autenticação (Basic Auth)
function authAdmin(req, res, next) {
    const auth = { login: ADMIN_LOGIN, password: ADMIN_SENHA };
    const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
    const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');

    if (login && password && login === auth.login && password === auth.password) {
        return next();
    }

    res.set('WWW-Authenticate', 'Basic realm="Area Restrita Admin"');
    res.status(401).send('Acesso Negado: Senha Incorreta.');
}

// ROTA: Tela do Admin
app.get('/admin', authAdmin, (req, res) => {
    const db = getDB();
    let listaKeys = "";
    
    // Gerar tabela
    for (const [key, dados] of Object.entries(db)) {
        listaKeys += `
        <tr>
            <td><span class="key-badge">${key}</span></td>
            <td style="color: #00e5ff; font-weight:bold;">${dados.limit}</td>
            <td style="text-align: right;">
                <a href="/admin/del/${key}" class="btn-del"><i class="fas fa-trash"></i></a>
            </td>
        </tr>`;
    }

    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ADMIN // NEXUS</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
        <style>
            body { background: #09090b; color: #e2e8f0; font-family: 'JetBrains Mono', monospace; padding: 20px; margin: 0; }
            h1 { color: #00e5ff; margin-bottom: 20px; text-transform: uppercase; font-size: 1.5rem; }
            
            /* Formulário de Criar */
            .box-add { background: #18181b; padding: 20px; border-radius: 8px; border: 1px solid #27272a; margin-bottom: 30px; }
            input { background: #000; border: 1px solid #3f3f46; color: white; padding: 12px; border-radius: 4px; width: 100%; margin-bottom: 10px; box-sizing: border-box; font-family: inherit; }
            input:focus { border-color: #00e5ff; outline: none; }
            
            button { background: #00e5ff; color: #000; font-weight: bold; border: none; padding: 12px; width: 100%; border-radius: 4px; cursor: pointer; }
            button:hover { background: #67e8f9; }

            /* Tabela */
            table { width: 100%; border-collapse: collapse; }
            th { text-align: left; color: #71717a; font-size: 0.8rem; padding-bottom: 10px; border-bottom: 1px solid #27272a; }
            td { padding: 15px 0; border-bottom: 1px solid #27272a; }
            
            .key-badge { background: rgba(255,255,255,0.05); padding: 5px 10px; border-radius: 4px; color: #fff; font-size: 0.9rem; }
            .btn-del { color: #ef4444; background: rgba(239, 68, 68, 0.1); padding: 8px 12px; border-radius: 4px; text-decoration: none; transition: 0.2s; }
            .btn-del:hover { background: #ef4444; color: white; }

            .top-nav { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
            .back-link { color: #71717a; text-decoration: none; font-size: 0.8rem; }
        </style>
    </head>
    <body>
        <div class="top-nav">
            <h1><i class="fas fa-user-shield"></i> PAINEL ADMIN</h1>
            <a href="/" class="back-link">VOLTAR AO SITE ↗</a>
        </div>

        <form action="/admin/add" method="POST" class="box-add">
            <label style="font-size: 0.8rem; color: #71717a;">NOVA KEY</label>
            <input type="text" name="key" placeholder="Ex: usuario_vip" required>
            
            <label style="font-size: 0.8rem; color: #71717a;">LIMITE DE REQUISIÇÕES</label>
            <input type="number" name="limit" placeholder="Ex: 1000" value="100" required>
            
            <button type="submit"><i class="fas fa-plus"></i> CRIAR / ATUALIZAR</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>KEY</th>
                    <th>SALDO</th>
                    <th style="text-align: right;">AÇÃO</th>
                </tr>
            </thead>
            <tbody>
                ${listaKeys}
            </tbody>
        </table>
    </body>
    </html>
    `);
});

// ROTA: Criar ou Atualizar Key (POST)
app.post('/admin/add', authAdmin, (req, res) => {
    const db = getDB();
    const { key, limit } = req.body;

    // Salva apenas o Limite (Removemos o campo 'plan')
    db[key] = { 
        limit: parseInt(limit) 
    };
    
    saveDB(db);
    res.redirect('/admin');
});

// ROTA: Deletar Key
app.get('/admin/del/:key', authAdmin, (req, res) => {
    const db = getDB();
    const keyParaDeletar = req.params.key;

    if (db[keyParaDeletar]) {
        delete db[keyParaDeletar];
        saveDB(db);
    }
    
    res.redirect('/admin');
});


app.get('/api/:cat/:met', async (req, res) => {
    const { cat, met } = req.params;
    const { apikey, q } = req.query;

    const db = getDB();
    const user = db[apikey];

    // 1. Verifica se a Key existe
    if (!user) {
        return res.status(403).json({ 
            status: false, 
            msg: "KEY INVALIDA OU NÃO ENCONTRADA" 
        });
    }
    
    // 2. Verifica se tem saldo (Limite > 0)
    if (!user.limit || user.limit <= 0) {
        return res.status(402).json({ 
            status: false, 
            msg: "SEM SALDO - SEU LIMITE ACABOU" 
        });
    }

    // 3. Desconta 1 crédito e salva imediatamente
    user.limit--; 
    saveDB(db);


    try {
        switch (cat) {
            
            case 'consultas':
                const metodo = met.toUpperCase(); // Facilita pra não repetir toUpperCase toda hora

                // --- 1. CONSULTA NOME ---
                if (metodo === 'NOME') {
                    if (!fs.existsSync(DB_NOME)) return res.json({ status: false, msg: "Banco OFF" });
                    
                    const stream = fs.createReadStream(DB_NOME);
                    const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
                    
                    let achou = false;
                    for await (const line of rl) {
                        if (line.toLowerCase().includes(q.toLowerCase())) {
                            try { res.json(JSON.parse(line)); achou = true; break; } catch (e) { continue; }
                        }
                    }
                    if (!achou) res.json({ status: false, msg: "Não encontrado" });

                // --- 2. CONSULTA CEP ---
                } else if (metodo === 'CEP') {
                    try {
                        const r = await axios.get(`https://viacep.com.br/ws/${q}/json/`);
                        res.json(r.data);
                    } catch (e) {
                        res.json({ status: false, msg: "CEP não encontrado ou inválido." });
                    }

                // --- 3. CONSULTA CNPJ ---
                } else if (metodo === 'CNPJ') {
                    try {
                        // Limpa pontos e traços do CNPJ pra evitar erro
                        const cnpjLimpo = q.replace(/[^0-9]/g, '');
                        const r = await axios.get(`https://brasilapi.com.br/api/cnpj/v1/${cnpjLimpo}`);
                        res.json(r.data);
                    } catch (e) {
                        res.json({ status: false, msg: "CNPJ não encontrado." });
                    }

                // --- 4. CONSULTA IP (AQUI ESTAVA O ERRO) ---
                } else if (metodo === 'IP') {
                    try {
                        let ip = q;
                        // Se não digitou nada, pega o IP da conexão
                        if (!ip) {
                            ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || '';
                            if (ip.includes('::ffff:')) ip = ip.replace('::ffff:', '');
                        }

                        // Se for localhost (::1 ou 127.0.0.1) a API não acha, então avisamos
                        if (ip === '::1' || ip === '127.0.0.1') {
                            return res.json({ status: false, msg: "Você está no Localhost (Servidor Local)." });
                        }

                        const { data } = await axios.get(`http://ipwho.is/${ip}`);

                        if (data.success) {
                            res.json({
                                status: true,
                                ip: data.ip,
                                tipo: data.type,
                                pais: data.country,
                                cidade: data.city,
                                provedor: data.connection.isp,
                                bandeira: data.flag.img
                            });
                        } else {
                            res.json({ status: false, msg: "IP Inválido." });
                        }
                    } catch (e) {
                        res.json({ status: false, msg: "Erro ao consultar IP." });
                    }

                // --- 5. ROTA NÃO ENCONTRADA ---
                } else {
                    res.json({ status: false, msg: "Consulta não encontrada ou em desenvolvimento" });
                }
                break;

            case 'ias':
                if (!q) return res.json({ status: false, msg: "Faltou a pergunta!" });
                switch (met.toUpperCase()) {
case 'GPT':
    try {
        const url = `https://shizuku-apis.shop/api/ias/gpt?query=${encodeURIComponent(q)}`;
        
        // 1. Faz a requisição
        const response = await axios.get(url);
        
        // 2. Pega o objeto JSON real
        const json = response.data;

        // 3. Verifica se o caminho existe para não dar erro de "undefined"
        if (json.resultado && json.resultado.data && json.resultado.data.length > 0) {
            
            // AQUI ESTÁ O SEGREDO: Navegar até o fundo do objeto
            const textoResposta = json.resultado.data[0].resposta;

            res.json({ 
                status: true, 
                modelo: "GPT-4o", 
                resposta: textoResposta 
            });

        } else {
            throw new Error("error.");
        }

    } catch (e) {
        // Fallback pro DuckDuckGo se a API falhar
        try {
            const rDuck = await axios.get(`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&pretty=1`);
            if(rDuck.data.AbstractText) {
                res.json({ status: true, modelo: "DuckDuckGo", resposta: rDuck.data.AbstractText });
            } else {
                res.status(500).json({ status: false, erro: "Não consegui responder." });
            }
        } catch (e2) { 
            res.status(500).json({ status: false, erro: "Serviço indisponível." }); 
        }
    }
    break;


case 'GEMINI':
    try {
        const query = req.query.q;
        
        if (!query) {
            return res.status(400).json({ status: false, msg: "Digite a pergunta." });
        }

        // 1. URL da API
        const url = `https://shizuku-apis.shop/api/ias/gemini?query=${encodeURIComponent(query)}`;
        
        // 2. Requisição
        const response = await axios.get(url);
        const json = response.data;

        // 3. Extração Direta (Baseado no JSON que você mandou)
        // O texto está direto em: json.resposta
        if (json.resposta) {
            res.json({
                status: true,
                modelo: "Gemini",
                resposta: json.resposta
            });
        } else {
            throw new Error("A API retornou, mas o campo 'resposta' veio vazio.");
        }

    } catch (e) {
        console.error("Erro Gemini:", e.message);
        
        // Fallback pro DuckDuckGo (Backup de segurança)
        try {
            const rDuck = await axios.get(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&pretty=1`);
            res.json({ 
                status: true, 
                modelo: "DuckDuckGo (Gemini Off)", 
                resposta: rDuck.data.AbstractText || "Gemini indisponível no momento." 
            });
        } catch (e2) {
            res.status(500).json({ status: false, erro: "Erro ao processar IA." });
        }
    }
    break;

                    default: res.status(404).json({ status: false, msg: "IA não encontrada" });
                }
                break;

            case 'downloads':
                switch (met.toUpperCase()) {
                    case 'YT_SEARCH':
                        if(!q) return res.json({status:false, msg:"Digite o nome"});
                        const rYt = await ytSearch(q);
                        if(rYt && rYt.videos.length>0) res.json({status:true, video: rYt.videos[0]});
                        else res.json({status:false, msg:"Nada achado"});
                        break;
case 'PLAYSTORE':
    try {
        const nomeApp = req.query.q;
        
        if (!nomeApp) return res.status(400).json({ status: false, msg: "Digite o nome do app." });

        // API SECRETA DA APTOIDE (Retorna JSON direto, muito rápido)
        const urlAptoide = `https://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(nomeApp)}&limit=1`;
        
        const { data } = await axios.get(urlAptoide);

        // Verifica se achou algo na lista
        if (data && data.datalist && data.datalist.list && data.datalist.list.length > 0) {
            
            const app = data.datalist.list[0]; // Pega o primeiro resultado

            res.json({
                status: true,
                criador: "Zyn",
                resultado: {
                    nome: app.name,
                    id_pacote: app.package,
                    desenvolvedor: app.developer ? app.developer.name : "Desconhecido",
                    nota: app.stats.rating.avg.toFixed(1), // Arredonda a nota (ex: 4.5)
                    downloads: app.stats.downloads,
                    versao: app.file.vername,
                    // Aptoide manda ícone direto
                    icone: app.icon,
                    // Montamos o link da Playstore original baseado no ID do pacote
                    link_playstore: `https://play.google.com/store/apps/details?id=${app.package}`,
                    link_download_aptoide: app.file.path || app.urls.generic,
                    atualizado_em: app.updated
                }
            });

        } else {
            throw new Error("App não encontrado.");
        }

    } catch (e) {
        console.error("Erro PlayStore (Aptoide):", e.message);
        res.status(500).json({ 
            status: false, 
            msg: "App não encontrado.",
        });
    }
    break;

                    case 'REDDIT':
                        try {
                            // 1. Busca os Top 50 posts do momento em JSON
                            const apiUrl = `https://www.reddit.com/r/memes/hot.json?limit=50`;
                            
                            // Headers fake pra o Reddit não bloquear o bot
                            const { data } = await axios.get(apiUrl, {
                                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
                            });

                            // 2. Filtra: Queremos apenas posts que sejam IMAGEM (.jpg, .png, .jpeg)
                            // Ignora vídeos, textos e links externos que não sejam foto direta
                            const posts = data.data.children;
                            const imagensValidas = posts.filter(post => {
                                const url = post.data.url;
                                return url && (url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg'));
                            });

                            if (imagensValidas.length > 0) {
                                // 3. Sorteia uma imagem da lista
                                const postSorteado = imagensValidas[Math.floor(Math.random() * imagensValidas.length)];
                                const urlImagem = postSorteado.data.url;

                                // 4. Baixa a imagem real
                                const imageResponse = await axios({
                                    method: 'get',
                                    url: urlImagem,
                                    responseType: 'stream' // O segredo para enviar direto
                                });

                                // 5. Define o tipo (JPEG/PNG) e envia pro bot/site
                                res.setHeader('Content-Type', imageResponse.headers['content-type']);
                                imageResponse.data.pipe(res);

                            } else {
                                res.status(404).json({ status: false, msg: `Não achei imagens no r/${subreddit}.` });
                            }

                        } catch (e) {
                            console.error("Erro Reddit:", e.message);
                            res.status(500).json({ status: false, msg: "Subreddit não encontrado ou bloqueado." });
                        }
                        break;
case 'PINTEREST':
    try {
        const query = req.query.q;

        if (!query) {
            return res.status(400).json({ status: false, msg: "Cade o texto? Ex: ?q=gato" });
        }

        // 1. O TRUQUE DO MESTRE 🎩
        // Em vez de adicionar "aesthetic", a gente força o Bing a olhar SÓ dentro do Pinterest.
        // E adicionamos '&adlt=off' pra desligar o filtro de conteúdo (pra aparecer Kid Bengala, etc).
        
        const searchTerms = encodeURIComponent(query + " site:pinterest.com");
        
        // adlt=off : Desliga o SafeSearch (Essencial pra nomes "polêmicos")
        // qft=+filterui:imagesize-large : Força imagens grandes
        const bingUrl = `https://www.bing.com/images/search?q=${searchTerms}&adlt=off&first=1&count=60&qft=+filterui:imagesize-large`;

        const { data: html } = await axios.get(bingUrl, {
            headers: {
                // Fingimos ser um navegador de PC pra ele não bloquear
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Cookie': 'SRCHHPGUSR=SRCHLANG=pt-BR&ADLT=OFF' // Força cookie sem restrição
            }
        });

        // 2. REGEX (Mantido, mas agora pega mais resultados)
        // O padrão i.pinimg.com é universal pro Pinterest
        const regex = /murl&quot;:&quot;(https:\/\/i\.pinimg\.com\/[^&"]+)&quot;/g;
        
        let match;
        const linksEncontrados = [];

        while ((match = regex.exec(html)) !== null) {
            const url = match[1];
            // Filtro de qualidade: Evita ícones pequenos (75x75, etc)
            if (!url.endsWith('.gif')) { // Evita GIF se não quiser
                linksEncontrados.push(url);
            }
        }

        if (linksEncontrados.length === 0) {
            // Se falhar com "site:pinterest.com", tenta o método antigo (fallback)
            throw new Error("Busca restrita falhou, tentando genérica...");
        }

        // 3. SELEÇÃO ALEATÓRIA
        // Pega um dos top 20 para variar, mas manter relevância
        const limite = Math.min(linksEncontrados.length, 20);
        const imagemEscolhida = linksEncontrados[Math.floor(Math.random() * limite)];

        // 4. ENVIO
        const imageResponse = await axios({
            method: 'get',
            url: imagemEscolhida,
            responseType: 'stream'
        });

        res.set('Content-Type', imageResponse.headers['content-type']);
        imageResponse.data.pipe(res);

    } catch (e) {
        // --- FALLBACK (PLANO B) ---
        // Se a busca "site:pinterest.com" não der nada, fazemos uma busca normal no Bing Images
        // mas filtrando manualmente as URLs depois.
        try {
            const fallbackUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(req.query.q)}&adlt=off`;
            const { data: htmlBackup } = await axios.get(fallbackUrl, { 
                headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
            });
            
            const regexBackup = /murl&quot;:&quot;(https:\/\/[^&"]+)&quot;/g;
            const linksBackup = [];
            let matchB;
            
            while ((matchB = regexBackup.exec(htmlBackup)) !== null) {
                // Tenta achar qualquer coisa que pareça imagem boa
                if (matchB[1].includes('pinimg') || matchB[1].includes('jpg') || matchB[1].includes('png')) {
                     linksBackup.push(matchB[1]);
                }
            }

            if (linksBackup.length > 0) {
                const imgBackup = linksBackup[Math.floor(Math.random() * Math.min(linksBackup.length, 5))];
                const respBackup = await axios.get(imgBackup, { responseType: 'stream' });
                res.set('Content-Type', respBackup.headers['content-type']);
                respBackup.data.pipe(res);
            } else {
                res.status(404).json({ status: false, msg: "Não encontrei nada." });
            }

        } catch (z) {
            console.error("Erro Pinterest Final:", z.message);
            res.status(404).json({ status: false, msg: "Erro ao buscar imagem." });
        }
    }
    break;

                    // --- YOUTUBE VÍDEO (STREAM DIRETO / SEM JSON) ---
                    case 'YT_VIDEO':
                        if (!q) return res.status(400).json({ status: false, msg: "Faltou o link ou nome!" });

                        try {
                            let urlVideo = q;

                            // 1. PESQUISA AUTOMÁTICA (Se não for link)
                            if (!q.startsWith('http')) {
                                const yts = require('yt-search'); 
                                const busca = await yts(q);
                                if (!busca.all || busca.all.length === 0) {
                                    return res.status(404).json({ status: false, msg: "Vídeo não encontrado." });
                                }
                                urlVideo = busca.all[0].url;
                            }

                            // 2. CONECTA NA API E PEDE O ARQUIVO (STREAM)
                            // responseType: 'stream' é o segredo para não travar a memória
                            const resposta = await axios({
                                method: 'GET',
                                url: `https://zero-two-apis.com.br/api/dl/ytvideo?url=${urlVideo}&apikey=Jpzinh9999`,
                                responseType: 'stream'
                            });

                            // 3. CONFIGURA CABEÇALHOS DE VÍDEO
                            res.setHeader('Content-Type', 'video/mp4');
                            
                            // 4. ENVIA O VÍDEO DIRETO PRO USUÁRIO
                            resposta.data.pipe(res);

                        } catch (e) {
                            console.error(e);
                            // Se der erro e o vídeo ainda não começou a ser enviado, avisa.
                            if (!res.headersSent) {
                                res.status(500).json({ status: false, msg: "Erro ao baixar vídeo." });
                            }
                        }
                        break;

case 'MEDIAFIRE':
    try {
        const urlMediafire = req.query.q;
        
        if (!urlMediafire) {
            return res.status(400).json({ status: false, msg: "Cole o link do Mediafire." });
        }

        // 1. Chama a API
        const { data } = await axios.get(`https://shizuku-apis.shop/api/downloads/mediafire-dl?url=${urlMediafire}`);

        // 2. Extrai os dados do ARRAY 'result'
        // O JSON vem assim: { result: [ { filename: "...", url: "..." } ] }
        if (data && data.result && data.result.length > 0) {
            
            const info = data.result[0]; // Pega o primeiro item da lista

            res.json({
                status: true,
                criador: "Zyn",
                arquivo: info.filename,
                tamanho: info.filesize,
                tipo: info.mimetype,
                // O link direto para download
                link_download: info.url 
            });

        } else {
            throw new Error("Arquivo não encontrado ou link privado.");
        }

    } catch (e) {
        console.error("Erro Mediafire:", e.message);
        res.status(500).json({ status: false, msg: "Erro ao buscar download." });
    }
    break;
    
case 'WALLPAPER':
    try {
        // 1. SCRAPER DO WALLHAVEN (Pega a lista de IDs)
        const seed = Math.random().toString(36).substring(7);
        const urlScrap = `https://wallhaven.cc/search?categories=111&purity=100&sorting=random&order=desc&seed=${seed}`;
        
        const { data: html } = await axios.get(urlScrap, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36' }
        });

        const $ = cheerio.load(html);
        let ids = [];
        
        $('figure.thumb').each((i, element) => {
            const id = $(element).attr('data-wallpaper-id'); // Ex: zy3wjO
            if (id) ids.push(id);
        });

        if (ids.length === 0) throw new Error("Sem imagens.");

        // 2. ESCOLHE UM ID ALEATÓRIO
        const idEscolhido = ids[Math.floor(Math.random() * ids.length)];
        const prefixo = idEscolhido.substring(0, 2);
        
        // 3. TENTA ADIVINHAR A URL (JPG ou PNG)
        // O Wallhaven não diz a extensão na busca, então tentamos JPG primeiro.
        let urlFinal = `https://w.wallhaven.cc/full/${prefixo}/wallhaven-${idEscolhido}.jpg`;
        let streamImagem;

        try {
            // Tenta baixar como JPG
            streamImagem = await axios({
                method: 'get',
                url: urlFinal,
                responseType: 'stream'
            });
        } catch (erroJPG) {
            // Se der erro (404), tenta PNG
            urlFinal = `https://w.wallhaven.cc/full/${prefixo}/wallhaven-${idEscolhido}.png`;
            streamImagem = await axios({
                method: 'get',
                url: urlFinal,
                responseType: 'stream'
            });
        }

        // 4. ENTREGA A IMAGEM DIRETO NA TELA
        res.setHeader('Content-Type', streamImagem.headers['content-type']);
        streamImagem.data.pipe(res);

    } catch (e) {
        console.error("Erro Wallpaper Stream:", e.message);
        
        // FALLBACK: Se o scraper falhar, manda uma do Unsplash direto (garantido)
        try {
            const unsplash = await axios({
                method: 'get',
                url: 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?ixlib=rb-4.0.3&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max',
                responseType: 'stream'
            });
            res.setHeader('Content-Type', 'image/jpeg');
            unsplash.data.pipe(res);
        } catch (e2) {
            res.status(500).json({ status: false, msg: "Erro ao gerar imagem." });
        }
    }
    break;

                    // --- YOUTUBE ÁUDIO (STREAM DIRETO) ---
                    case 'YT_AUDIO':
                        if (!q) return res.json({ status: false, msg: "Faltou o nome ou link!" });

                        try {
                            let urlVideo = q;

                            // 1. SE O USUÁRIO MANDOU SÓ O NOME, A GENTE PESQUISA O LINK SOZINHO
                            if (!q.startsWith('http')) {
                                const yts = require('yt-search'); // Garanta que tem essa linha no topo do arquivo
                                const busca = await yts(q);
                                if (!busca.all || busca.all.length === 0) {
                                    return res.json({ status: false, msg: "Música não encontrada." });
                                    // Nota: Se usar res.json aqui, o bot tem que saber tratar erro JSON vs Arquivo
                                }
                                urlVideo = busca.all[0].url;
                            }

                            // 2. CONECTA NA API EXTERNA PEDINDO O FLUXO DE DADOS (STREAM)
                            // responseType: 'stream' é o segredo aqui.
                            const resposta = await axios({
                                method: 'GET',
                                url: `https://zero-two-apis.com.br/api/dl/ytaudio?url=${urlVideo}&apikey=Jpzinh9999`,
                                responseType: 'stream' 
                            });

                            // 3. DEFINE QUE O QUE VAMOS MANDAR É UM ÁUDIO MP3
                            res.setHeader('Content-Type', 'audio/mpeg');
                            
                            // (Opcional) Força o download com o nome do arquivo se a API mandar
                            // res.setHeader('Content-Disposition', 'attachment; filename="musica.mp3"');

                            // 4. "LIGA A MANGUEIRA": O áudio sai da Zero Two -> Entra na sua API -> Sai pro Usuário
                            resposta.data.pipe(res);

                        } catch (e) {
                            // Se der erro no meio do caminho, tentamos avisar (mas se o áudio já começou, falha)
                            console.error(e);
                            if (!res.headersSent) {
                                res.status(500).json({ status: false, msg: "Erro ao processar o áudio." });
                            }
                        }
                        break;
                        
                    case 'INSTAGRAM':
                        if (!q) return res.json({ status: false, msg: "Cadê o link?" });

                        try {
                            // API Siputzx (Estável para Reels e Posts)
                            const apiUrl = `https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(q)}`;
                            
                            const { data } = await axios.get(apiUrl);

                            if (data.status && data.data && data.data.length > 0) {
                                res.json({
                                    status: true,
                                    // Pega o primeiro link (se for vídeo ou foto única)
                                    url: data.data[0].url,
                                    thumb: data.data[0].thumbnail,
                                    // Manda a lista completa caso seja um carrossel (várias fotos)
                                    midias: data.data 
                                });
                            } else {
                                res.json({ status: false, msg: "Perfil privado ou link quebrado." });
                            }
                        } catch (e) {
                            res.status(500).json({ status: false, msg: "Erro ao baixar do Instagram." });
                        }
                        break;

                    case 'TIKTOK':
                        const rTik = await axios.get(`https://www.tikwm.com/api/?url=${q}`);
                        res.json(rTik.data);
                        break;
                }
                break;

            case 'fig':
                switch(met.toUpperCase()) {
                    case 'FIGURINHAS':
                        try {
                            const response = await axios({ method: 'get', url: 'https://shizuku-apis.shop/api/stickers/figurinhas', responseType: 'stream' });
                            res.set('Content-Type', response.headers['content-type']);
                            response.data.pipe(res);
                        } catch (e) { res.status(500).json({ status: false, msg: "Erro API" }); }
                        break;
                        case 'FIGU_EMOJI':
    try {
        // 1. Acessa a API já pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_emoji',
            responseType: 'stream' // <--- O SEGREDO ESTÁ AQUI
        });

        // 2. Descobre qual o tipo da imagem (webp, png, etc) que a API mandou
        const tipoImagem = response.headers['content-type'];
        
        // 3. Avisa pro navegador do usuário que vai chegar uma imagem
        res.setHeader('Content-Type', tipoImagem);

        // 4. Conecta o "cano" e manda a imagem
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Emoji:", e.message);
        // Se der erro (ex: API offline), manda JSON avisando
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha." });
        }
    }
    break;
    
                            case 'FIGU_DESENHO':
    try {
        // 1. Acessa a API já pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_desenho',
            responseType: 'stream' // <--- O SEGREDO ESTÁ AQUI
        });

        // 2. Descobre qual o tipo da imagem (webp, png, etc) que a API mandou
        const tipoImagem = response.headers['content-type'];
        
        // 3. Avisa pro navegador do usuário que vai chegar uma imagem
        res.setHeader('Content-Type', tipoImagem);

        // 4. Conecta o "cano" e manda a imagem
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Emoji:", e.message);
        // Se der erro (ex: API offline), manda JSON avisando
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha." });
        }
    }
    break;
    
                                case 'FIGU_ANIMAL':
    try {
        // 1. Acessa a API já pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_animais',
            responseType: 'stream' // <--- O SEGREDO ESTÁ AQUI
        });

        // 2. Descobre qual o tipo da imagem (webp, png, etc) que a API mandou
        const tipoImagem = response.headers['content-type'];
        
        // 3. Avisa pro navegador do usuário que vai chegar uma imagem
        res.setHeader('Content-Type', tipoImagem);

        // 4. Conecta o "cano" e manda a imagem
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Animal:", e.message);
        // Se der erro (ex: API offline), manda JSON avisando
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha." });
        }
    }
    break;
    
    case 'FIGU_ANIME':
    try {
        // 1. Conecta na API pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_anime',
            responseType: 'stream'
        });

        // 2. Pega o tipo da imagem (webp, png, gif...)
        res.setHeader('Content-Type', response.headers['content-type']);

        // 3. Manda direto pro usuário
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Anime:", e.message);
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha de anime." });
        }
    }
    break;
    

                    // --- BRAT (IMAGEM / STICKER) ---
                    case 'BRAT':
                        if (!q) return res.json({ status: false, msg: "Escreva o texto!" });
                        try {
                            // Endpoint de imagem (Troca /gif por /brat)
                            const apiUrl = `https://brat.siputzx.my.id/image?text=${encodeURIComponent(q)}`;

                            const response = await axios({
                                method: 'get',
                                url: apiUrl,
                                responseType: 'stream'
                            });

                            // Define o tipo correto e envia
                            res.setHeader('Content-Type', response.headers['content-type']);
                            response.data.pipe(res);

                        } catch (e) {
                            console.error("Erro Brat Img:", e.message);
                            res.status(500).json({ status: false, msg: "Erro na API Brat Imagem." });
                        }
                        break;

                    // --- BRAT (VÍDEO / GIF) ---
                    case 'BRAT_VIDEO':
                        if (!q) return res.json({ status: false, msg: "Escreva o texto!" });
                        try {
                            // Endpoint de GIF/Video
                            const apiUrl = `https://brat.siputzx.my.id/gif?text=${encodeURIComponent(q)}`;

                            const response = await axios({
                                method: 'get',
                                url: apiUrl,
                                responseType: 'stream'
                            });

                            // A API retorna um GIF ou MP4
                            res.setHeader('Content-Type', response.headers['content-type']);
                            response.data.pipe(res);

                        } catch (e) {
                            console.error("Erro Brat Video:", e.message);
                            res.status(500).json({ status: false, msg: "Erro na API Brat Vídeo." });
                        }
                        break;

// --- TTP: PLACA NEON (Garantido 100%) ---
case 'TTP':
    try {
        const texto = req.query.q || 'Nexus';
        
        // Placehold.co é feito pra aguentar tranco.
        // 101010 = Fundo Preto | 00ff99 = Texto Verde Neon
        const url = `https://placehold.co/512x512/101010/00ff99/png?text=${encodeURIComponent(texto)}&font=montserrat`;

        const response = await axios({
            method: 'get',
            url: url,
            responseType: 'stream'
        });

        // Manda como PNG direto
        res.setHeader('Content-Type', 'image/png');
        response.data.pipe(res);

    } catch (e) {
        res.status(500).json({ status: false, msg: "Erro TTP" });
    }
    break;

// --- ATTP: GERADOR NATIVO (Sem depender de site externo) ---
case 'ATTP':
    try {
        let texto = req.query.q || 'NEXUS';
        
        if (texto.length > 20) texto = texto.substring(0, 20);

        // O SEGREDO DO SUCESSO: preserveAspectRatio="xMidYMid slice"
        // Tradução: "Dê zoom até preencher a tela toda (slice), mas mantenha o centro (Mid) focado."
        // Resultado: O fundo preto cobre tudo, e o texto NÃO estica.

        const svgAnimado = `
        <svg version="1.1" 
             xmlns="http://www.w3.org/2000/svg" 
             width="100%" 
             height="100%" 
             viewBox="0 0 512 512" 
             preserveAspectRatio="xMidYMid slice">
            
            <rect width="100%" height="100%" fill="black" />

            <text x="50%" y="50%" 
                  dominant-baseline="middle" 
                  text-anchor="middle" 
                  font-family="Arial Black, Impact, sans-serif" 
                  font-weight="900" 
                  font-size="90" 
                  fill="white">
                ${texto.toUpperCase()}

                <animate attributeName="fill" values="#ff0000;#ffff00;#00ff00;#00ffff;#0000ff;#ff00ff;#ff0000" dur="0.2s" repeatCount="indefinite" />
                
                <animate attributeName="stroke" values="white;black;white" dur="0.2s" repeatCount="indefinite" />
                <animate attributeName="stroke-width" values="2;0;2" dur="0.2s" repeatCount="indefinite" />
            </text>
        </svg>`;

        res.setHeader('Content-Type', 'image/svg+xml');
        // Headers pra garantir que não carregue versão velha cacheada
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        
        res.send(svgAnimado);

    } catch (e) {
        res.status(500).send("Erro");
    }
    break;

    case 'FIGU_FUNNY':
    try {
        // 1. Conecta na API pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_engracadas',
            responseType: 'stream'
        });

        // 2. Pega o tipo da imagem (webp, png, gif...)
        res.setHeader('Content-Type', response.headers['content-type']);

        // 3. Manda direto pro usuário
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Funny:", e.message);
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha de anime." });
        }
    }
    break;
    
        case 'FIGU_RAIVA':
    try {
        // 1. Conecta na API pedindo o fluxo de dados (stream)
        const response = await axios({
            method: 'get',
            url: 'https://shizuku-apis.shop/api/stickers/figu_raiva',
            responseType: 'stream'
        });

        // 2. Pega o tipo da imagem (webp, png, gif...)
        res.setHeader('Content-Type', response.headers['content-type']);

        // 3. Manda direto pro usuário
        response.data.pipe(res);

    } catch (e) {
        console.error("Erro Figu Raiva:", e.message);
        if (!res.headersSent) {
            res.status(500).json({ status: false, msg: "Erro ao baixar a figurinha de anime." });
        }
    }
    break;
    
                    case 'ROBLOX':
                        try {
                            const linksPinterest = [
                                "https://pin.it/widsHLcEs",
                                "https://pin.it/JBDrDJO80",
                                "https://pin.it/10ZnRVFF6",
                                "https://pin.it/v6zYPj8sf",
                                "https://pin.it/5bKlNJq0S",
                                "https://pin.it/4Ohobt7J2",
                                "https://pin.it/2SI0zxvpm",
                                "https://pin.it/5mqPJnywU",
                                "https://pin.it/72hSgDTcV",
                                "https://pin.it/3MEciyoXV",
                                "https://pin.it/4dVNwOKao",
                                "https://pin.it/6kz4PtFpU",
                                "https://pin.it/3hvi2MT9o",
                                "https://pin.it/pdBAU9RHa",
                                "https://pin.it/2ObwhDQxQ",
                                "https://pin.it/1Zj9a9xzI",
                                "https://pin.it/7LRx5idPz",
                                "https://pin.it/4m60jJUMW",
                                "https://pin.it/6l5ye5KJp",
                                "https://pin.it/4xRTkHWay",
                                "https://pin.it/479vK8VAS"
                            ];

                            const randomLink = linksPinterest[Math.floor(Math.random() * linksPinterest.length)];

                            // 1. Pega o HTML da página (com User-Agent de celular pra carregar mais leve)
                            const { data: html } = await axios.get(randomLink, {
                                headers: {
                                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.81 Mobile Safari/537.36',
                                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
                                }
                            });

                            // 2. TÁTICA NOVA: Regex que busca qualquer link de imagem do Pinterest no HTML
                            // Procura por: https://i.pinimg.com/ (qualquer coisa) .jpg ou .png
                            const regexImagem = /https:\/\/i\.pinimg\.com\/[a-zA-Z0-9\/._-]+\.(jpg|png|webp)/;
                            const match = html.match(regexImagem);
                            
                            if (!match || !match[0]) {
                                // Se falhar, usa uma imagem de backup pra não dar erro pro usuario
                                console.log("Falha no regex, usando backup.");
                                var directImageUrl = "https://i.pinimg.com/originals/f6/5c/28/f65c287236df79075bc5798993883b48.jpg";
                            } else {
                                // Pega a imagem encontrada. Às vezes o Pinterest manda a pequena (75x75),
                                // esse replace tenta forçar a original se encontrar o padrão.
                                directImageUrl = match[0].replace('/75x75/', '/originals/').replace('/236x/', '/originals/');
                            }

                            // 3. Baixa a imagem final
                            const imageResponse = await axios({
                                method: 'get',
                                url: directImageUrl,
                                responseType: 'stream'
                            });

                            res.set('Content-Type', imageResponse.headers['content-type']);
                            imageResponse.data.pipe(res);

                        } catch (e) {
                            console.error("Erro API Roblox:", e.message);
                            if (!res.headersSent) {
                                res.status(500).json({ status: false, msg: "Erro ao buscar figurinha." });
                            }
                        }
                        break;

                }
                break;

            case 'ferramentas':
                switch (met.toUpperCase()) {
                    case 'CLIMA':
                        if (!q) return res.json({ status: false, msg: "Qual a cidade?" });
                        try {
                            const { data } = await axios.get(`https://wttr.in/${encodeURIComponent(q)}?format=j1&lang=pt`);
                            const atual = data.current_condition[0];
                            const regiao = data.nearest_area[0];
                            res.json({ status: true, cidade: regiao.areaName[0].value, temperatura: atual.temp_C + "°C", condicao: atual.lang_pt[0].value });
                        } catch (e) { res.status(500).json({ status: false, msg: "Cidade não encontrada." }); }
                        break;
                        
                                            case 'GERAR_NICK': res.json({ status: true, styles: stylizeText(q) }); break;
                                            case 'TTS':
                        if (!q) return res.json({ status: false, msg: "O que eu devo falar?" });

                        try {
                            // API do Google Translate TTS (Totalmente Grátis e Estável)
                            // tl=pt-br define o idioma
                            const googleTTSUrl = `http://translate.google.com/translate_tts?ie=UTF-8&total=1&idx=0&textlen=32&client=tw-ob&q=${encodeURIComponent(q)}&tl=pt-br`;

                            const response = await axios({
                                method: 'get',
                                url: googleTTSUrl,
                                responseType: 'stream'
                            });

                            // Envia como áudio MP3
                            res.setHeader('Content-Type', 'audio/mpeg');
                            response.data.pipe(res);

                        } catch (e) {
                            console.error("Erro TTS:", e.message);
                            res.status(500).json({ status: false, msg: "Erro ao gerar áudio." });
                        }
                        break;
                        
                    case 'TRADUTOR':
                        if (!q) return res.json({ status: false, msg: "O que quer traduzir?" });
                        try {
                            const urlTrad = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=pt&dt=t&q=${encodeURIComponent(q)}`;
                            const { data } = await axios.get(urlTrad);
                            res.json({ status: true, original: q, traducao: data[0][0][0] });
                        } catch (e) { res.status(500).json({ status: false, msg: "Erro ao traduzir." }); }
                        break;
                    case 'PRINTSITE':
                        if (!q) return res.json({ status: false, msg: "Cade o link?" });
                        try {
                            let link = q.trim();
                            if (!link.startsWith('http')) link = `https://${link}`;
                            const urlApi = `https://image.thum.io/get/width/1280/crop/720/noanimate/${link}`;
                            const response = await axios({ method: 'get', url: urlApi, responseType: 'stream' });
                            res.setHeader('Content-Type', 'image/jpeg');
                            response.data.pipe(res);
                        } catch (e) { res.status(500).json({ status: false, msg: "Erro ao gerar print." }); }
                        break;
                    case 'ENCURTAR':
                        if (!q) return res.json({ status: false, msg: "Cade o link?" });
                        try {
                            const { data } = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(q)}`);
                            res.json({ status: true, link: data });
                        } catch (e) { res.status(500).json({ status: false, msg: "Erro ao encurtar." }); }
                        break;
                }
                break;

            // ======================================================
            // 🧠 MÓDULO INFORMAÇÃO
            // ======================================================
            case 'info':
                switch (met.toUpperCase()) {
case 'G1':
    try {
        const urlG1 = 'https://g1.globo.com/';

        // 1. Acessa o site fingindo ser gente (User-Agent é essencial pro G1 não bloquear)
        const { data: html } = await axios.get(urlG1, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
            }
        });

        // 2. Carrega o HTML
        const $ = cheerio.load(html);
        let noticias = [];

        // 3. Raspagem (Scraping)
        // O G1 usa a classe '.feed-post-body' para cada cartão de notícia
        $('.feed-post-body').each((i, element) => {
            if (i >= 7) return; // Limita a 7 notícias pra ser rápido

            // Pega o Título
            const titulo = $(element).find('.feed-post-link').text().trim();
            
            // Pega o Link
            const link = $(element).find('.feed-post-link').attr('href');
            
            // Pega o Resumo (nem sempre tem)
            const resumo = $(element).find('.feed-post-body-resumo').text().trim() || "Sem resumo disponível.";
            
            // Pega o Tempo (ex: "há 2 horas")
            const tempo = $(element).find('.feed-post-metadata-main-time').text().trim();
            
            // Pega a Seção (ex: "Política", "Economia")
            const secao = $(element).find('.feed-post-metadata-section').text().trim();

            // Pega a Imagem (Essa é a parte chata, o G1 usa lazy load)
            // A imagem costuma estar numa div acima, mas no container pai.
            // Vamos tentar achar a imagem mais próxima no bloco pai.
            let imagem = $(element).parents('.bastian-feed-item').find('img.bstn-fd-picture-image').attr('src');
            
            // Se não achar no src, tenta no srcset (imagens responsivas)
            if (!imagem) {
                const srcset = $(element).parents('.bastian-feed-item').find('img.bstn-fd-picture-image').attr('srcset');
                if (srcset) {
                    // Pega a primeira url do srcset
                    imagem = srcset.split(' ')[0];
                }
            }

            // Fallback de imagem se não tiver nenhuma
            if (!imagem) imagem = "https://s2.glbimg.com/g1/logo.png";

            if (titulo && link) {
                noticias.push({
                    titulo: titulo,
                    resumo: resumo,
                    categoria: secao || "Geral",
                    tempo: tempo,
                    link: link,
                    imagem: imagem,
                    fonte: "G1 Oficial"
                });
            }
        });

        res.json({
            status: true,
            origem: "Scraper G1 Nativo",
            total: noticias.length,
            noticias: noticias
        });

    } catch (e) {
        console.error("Erro Scraper G1:", e.message);
        res.status(500).json({ status: false, msg: "Erro ao acessar G1. O layout pode ter mudado." });
    }
    break;

case 'POLITICA':
    try {
        const https = require('https');
        const agent = new https.Agent({ rejectUnauthorized: false });

        // 1. TENTA GOOGLE NEWS (Rápido, Sem Bloqueio, Sem Imagem)
        const urlGoogle = 'https://news.google.com/rss/search?q=politica+brasil+when:1d&hl=pt-BR&gl=BR&ceid=BR:pt-419';

        const { data: xml } = await axios.get(urlGoogle, { 
            httpsAgent: agent,
            headers: { 'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1)' }
        });

        const $ = cheerio.load(xml, { xmlMode: true });
        let noticias = [];

        $('item').each((i, el) => {
            if (i >= 10) return;

            const titulo = $(el).find('title').text();
            const link = $(el).find('link').text();
            const dataPub = $(el).find('pubDate').text();
            const fonte = $(el).find('source').text() || "Google News";

            noticias.push({
                titulo: titulo,
                fonte: fonte,
                data: dataPub,
                link: link
                // REMOVI A IMAGEM DAQUI
            });
        });

        if (noticias.length > 0) {
            res.json({
                status: true,
                origem: "Google News",
                total: noticias.length,
                noticias: noticias
            });
        } else {
            throw new Error("Google News vazio.");
        }

    } catch (e) {
        console.error("Erro Google News:", e.message);

        // --- PLANO B: IBGE (Esse TEM imagem oficial e não bloqueia) ---
        try {
            const ibgeUrl = 'http://servicodados.ibge.gov.br/api/v3/noticias/?qtd=5&introsize=100';
            const { data: ibgeData } = await axios.get(ibgeUrl);

            const newsIbge = ibgeData.items.map(item => {
                // O IBGE manda a imagem num JSON dentro de string, precisa tratar
                let foto = null;
                try {
                    const imagens = JSON.parse(item.imagens);
                    if (imagens && imagens.image_intro) {
                        foto = "https://agenciadenoticias.ibge.gov.br/" + imagens.image_intro;
                    }
                } catch(err) {}

                return {
                    titulo: item.titulo,
                    fonte: "IBGE Oficial",
                    data: item.data_publicacao,
                    link: item.link,
                    imagem: foto // Aqui mantivemos pq é real
                };
            });

            res.json({ 
                status: true, 
                msg: "Mostrando notícias oficiais do IBGE.", 
                noticias: newsIbge 
            });

        } catch (e2) {
            res.status(500).json({ status: false, msg: "Erro ao buscar notícias." });
        }
    }
    break;

case 'FUTEBOL':
    try {
        // --- PLANO A: CNN ESPORTES (Via Proxy para pegar Imagens) ---
        // Usamos o rss2json para não bloquerem o IP da Lunes Host
        const urlProxy = 'https://api.rss2json.com/v1/api.json?rss_url=https://www.cnnbrasil.com.br/esportes/feed/';
        
        const { data } = await axios.get(urlProxy);

        if (data.status === 'ok' && data.items.length > 0) {
            
            const noticiasFutebol = data.items.map(item => ({
                titulo: item.title,
                // O resumo vem com HTML, limpamos para ficar só texto
                resumo: item.description.replace(/<[^>]*>?/gm, '').slice(0, 100) + "...",
                data: item.pubDate,
                link: item.link,
                // Tenta pegar a imagem do thumbnail ou usa uma de campo de futebol
                imagem: item.thumbnail || item.enclosure?.link || "https://images.unsplash.com/photo-1522778119026-d647f0565c6d?auto=format&fit=crop&w=500&q=60",
                fonte: "CNN Esportes"
            }));

            res.json({
                status: true,
                origem: "CNN Esportes (Com Imagens)",
                total: noticiasFutebol.length,
                noticias: noticiasFutebol
            });

        } else {
            throw new Error("Proxy CNN retornou vazio.");
        }

    } catch (e) {
        console.error("Erro Futebol Imagens:", e.message);

        // --- PLANO B: GOOGLE NEWS (Backup Blindado - Sem Imagens) ---
        try {
            const https = require('https');
            const agent = new https.Agent({ rejectUnauthorized: false });
            
            // Feed do Google filtrado por "Futebol Brasileiro"
            const urlGoogle = 'https://news.google.com/rss/search?q=futebol+brasileiro+when:1d&hl=pt-BR&gl=BR&ceid=BR:pt-419';

            const { data: xml } = await axios.get(urlGoogle, { 
                httpsAgent: agent,
                headers: { 'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1)' }
            });

            const $ = cheerio.load(xml, { xmlMode: true });
            let backupNews = [];

            $('item').each((i, el) => {
                if(i >= 8) return;
                backupNews.push({
                    titulo: $(el).find('title').text(),
                    fonte: $(el).find('source').text() || "Google News",
                    data: $(el).find('pubDate').text(),
                    link: $(el).find('link').text()
                });
            });

            res.json({ 
                status: true, 
                msg: "Imagens indisponíveis. Mostrando manchetes do Google News.", 
                noticias: backupNews 
            });

        } catch (e2) {
            res.status(500).json({ status: false, msg: "Erro ao buscar notícias de esporte." });
        }
    }
    break;
    
                    default:
                        res.status(404).json({ msg: "Comando de info não encontrado." });
                }
                break;

            // ======================================================
            // 🔞 MÓDULO NSFW (+18) - Se você tiver rotas aqui
            // ======================================================
            case 'nsfw':
                switch (met.toUpperCase()) {
                     case 'PLAQUINHA':
                        if (!q) return res.json({ status: false, msg: "Escreva o texto!" });

                        try {
                            // API Shizuku (Token Fixo: Shizuku-channel)
                            // O parâmetro de texto dela é 'query'
                            const apiUrl = `https://shizuku-apis.shop/api/plaquinhas/plaq1?query=${encodeURIComponent(q)}`;

                            const response = await axios({
                                method: 'get',
                                url: apiUrl,
                                responseType: 'stream' // Importante para baixar a imagem direto
                            });

                            // Define o tipo de arquivo (JPEG) e envia
                            res.setHeader('Content-Type', 'image/jpeg');
                            response.data.pipe(res);

                        } catch (e) {
                            console.error("Erro:", e.message);
                            res.status(500).json({ status: false, msg: "Erro na API." });
                        }
                        break;
                        case 'PH_SEARCH':
    try {
        const termo = req.query.q;
        if (!termo) return res.status(400).json({ status: false, msg: "Digite o que procura." });

        // URL de pesquisa
        const urlBusca = `https://www.pornhub.com/video/search?search=${encodeURIComponent(termo)}`;

        // HEADERS REAIS (Para enganar o sistema deles)
        const { data: html } = await axios.get(urlBusca, {
            headers: {
                // Finge ser um Chrome no Windows
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                // Cookie que diz "Já aceitei os termos" e "Sou maior de idade"
                'Cookie': 'age_verified=1; platform=pc; accessAgeDisclaimerPH=1; bs=1',
                'Referer': 'https://www.pornhub.com/'
            }
        });

        const $ = cheerio.load(html);
        let videos = [];

        // O Hub organiza os vídeos numa lista com ID #videoCategory ou classe .videoBox
        // Eles mudam isso as vezes, mas o padrão é buscar por 'li.js-pop'
        $('li.js-pop, .pcVideoListItem').each((i, element) => {
            if (i >= 10) return; // Limita a 10 vídeos

            // 1. Título e Link
            const linkTag = $(element).find('a').first();
            const titulo = $(element).find('.title a').text().trim() || linkTag.attr('title');
            let link = $(element).find('.title a').attr('href') || linkTag.attr('href');

            // 2. Capa (Thumbnail)
            // Eles usam lazy load, então a imagem tá no 'data-src' ou 'data-mediumthumb'
            const imgTag = $(element).find('img');
            const thumb = imgTag.attr('data-src') || imgTag.attr('src') || imgTag.attr('data-mediumthumb');

            // 3. Duração e Views
            const tempo = $(element).find('.duration').text().trim();
            const views = $(element).find('.views').text().replace('views', '').trim();

            // Validação (Pra não pegar propaganda)
            if (titulo && link && !link.includes('javascript')) {
                videos.push({
                    titulo: titulo,
                    tempo: tempo,
                    views: views,
                    // O link vem relativo (/view_video...), precisa colocar o dominio antes
                    link: `https://www.pornhub.com${link}`,
                    imagem: thumb
                });
            }
        });

        if (videos.length > 0) {
            res.json({
                status: true,
                criador: "Zyn",
                termo: termo,
                total: videos.length,
                resultados: videos
            });
        } else {
            // Se der erro, pode ser bloqueio de região ou seletores mudaram
            throw new Error("Nenhum vídeo encontrado ou bloqueio ativo.");
        }

    } catch (e) {
        console.error("Erro Hub:", e.message);
        res.status(500).json({ 
            status: false, 
            msg: "Erro ao buscar vídeos. O servidor pode estar bloqueado." 
        });
    }
    break;
    
    case 'XNXX':
    try {
        const query = req.query.q;
        if (!query) return res.status(400).json({ status: false, msg: "Digite o termo. Ex: /xnxx mia khalifa" });

        const cheerio = require('cheerio');

        // --- 1. BUSCA (Página de Pesquisa) ---
        console.log(`[XNXX] Pesquisando: ${query}`);
        const urlBusca = `https://www.xnxx.com/search/${encodeURIComponent(query)}`;

        const { data: htmlBusca } = await axios.get(urlBusca);
        const $ = cheerio.load(htmlBusca);

        const linksVideos = [];
        // Pega os links dentro da div .thumb-block
        $('.thumb-block .thumb a').each((i, elem) => {
            const link = $(elem).attr('href');
            if (link && !link.includes('/profiles/')) {
                linksVideos.push(`https://www.xnxx.com${link}`);
            }
        });

        if (linksVideos.length === 0) {
            return res.status(404).json({ status: false, msg: "Nenhum vídeo encontrado." });
        }

        // Escolhe um aleatório da primeira página
        const linkEscolhido = linksVideos[Math.floor(Math.random() * linksVideos.length)];
        console.log(`[XNXX] Alvo: ${linkEscolhido}`);

        // --- 2. EXTRAÇÃO (Página do Vídeo) ---
        const { data: htmlVideo } = await axios.get(linkEscolhido);
        
        // O link MP4 tá dentro de um script JS: setVideoUrlHigh('LINK')
        // Usamos Regex pra pegar o que tá dentro das aspas
        const regexHigh = /html5player\.setVideoUrlHigh\('([^']+)'\)/;
        const regexLow = /html5player\.setVideoUrlLow\('([^']+)'\)/; // Backup (baixa qualidade)

        let match = regexHigh.exec(htmlVideo);
        if (!match) match = regexLow.exec(htmlVideo);

        if (match && match[1]) {
            const linkMp4 = match[1];

            // --- 3. DOWNLOAD & STREAM ---
            const videoStream = await axios({
                method: 'GET',
                url: linkMp4,
                responseType: 'stream'
            });

            res.setHeader('Content-Type', 'video/mp4');
            // Nome do arquivo aleatório pra não dar pala
            res.setHeader('Content-Disposition', `attachment; filename="video_${Date.now()}.mp4"`);
            
            if (videoStream.headers['content-length']) {
                res.setHeader('Content-Length', videoStream.headers['content-length']);
            }

            videoStream.data.pipe(res);

        } else {
            throw new Error("Não achei o link do MP4 dentro da página.");
        }

    } catch (e) {
        console.error("Erro XNXX:", e.message);
        res.status(500).json({ status: false, msg: "Erro ao baixar vídeo." });
    }
    break;
    
    
                    default:
                        res.status(404).json({ msg: "Comando +18 não encontrado." });
                }
                break;

            // ======================================================
            // ❌ ROTA PADRÃO (SE A CATEGORIA NÃO EXISTIR)
            // ======================================================
            default:
                res.status(404).json({ msg: "Categoria inválida." });
        }
    
    } catch (e) { 
        console.error(e);
        res.status(500).json({ status: false, erro: "Erro interno no servidor." }); 
    }
});

// Inicializa o Servidor
app.listen(PORT, () => console.log(`✅ Rodando em http://localhost:${PORT}`));
